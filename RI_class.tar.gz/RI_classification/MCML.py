import numpy as np
import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.models import Model


def multilabel_to_categorical(data,num_classes):
  j=0
  cat = np.zeros([len(data),num_classes])
  for d in data:
    if d==1: cat[j,:] = [0,0,0]
    elif d==2: cat[j,:]=[1,0,0]
    elif d==3: cat[j,:]=[0,1,0]
    elif d==4: cat[j,:]=[0,0,1]
    elif d==5: cat[j,:]=[1,1,0]
    elif d==6: cat[j,:]=[1,0,1]
    elif d==7: cat[j,:]=[0,1,1]
    elif d==8: cat[j,:]=[1,1,1]
    j += 1
  return cat


def mc_ml_feature(l_input,l_feature,droprate):
  input_data = layers.Input(shape=(l_input,))
  L1 = layers.Dense(300,activation='ReLU')(input_data)
  L1 = layers.Dropout(droprate)(L1)
  L2 = layers.Dense(300,activation='ReLU')(L1)
  L2 = layers.Dropout(droprate)(L2)
  return Model(input_data,L2)

def MC_out(l_feature,output_mc):
  input_data = layers.Input(shape=(l_feature,))
  output = layers.Dense(output_mc,activation='softmax')(input_data)
  return Model(input_data,output)

def ML_out(l_feature,output_ml):
  input_data = layers.Input(shape=(l_feature,))
  output = layers.Dense(output_ml,activation='sigmoid')(input_data)
  return Model(input_data,output)

class MCML(tf.keras.Model):
  def __init__(self,l_input=500,l_feature=300,l_mc=8,l_ml=3,droprate=0.3,**kwargs):
    super(MCML, self).__init__(**kwargs)
    self.l_input = l_input
    self.l_feature = l_feature
    self.l_mc = l_mc
    self.l_ml = l_ml
    self.droprate = droprate

    self.feature_extractor = mc_ml_feature(l_input,l_feature,droprate)
    self.mc_classout = MC_out(l_feature,l_mc)
    self.ml_classout = ML_out(l_feature,l_ml)

    self.MC_opt = tf.keras.optimizers.Adam(1e-4)
    self.ML_opt = tf.keras.optimizers.Adam(1e-4)
    
    self.total_loss_tracker = tf.keras.metrics.Sum(name="total_loss")
    self.mc_loss_tracker = tf.keras.metrics.Mean(name="mc_loss")
    self.ml_loss_tracker = tf.keras.metrics.Mean(name="ml_loss")
    self.mc_acc_tracker = tf.keras.metrics.Mean(name="mc_acc")
    self.ml_acc_tracker = tf.keras.metrics.Mean(name="ml_acc")

  def train_step(self,data):
    x,y_mc,y_ml = data
    y_ml = tf.cast(y_ml,y_mc.dtype)
    with tf.GradientTape() as mc_tape:
      Features = self.feature_extractor(x,training=True)
      Classes = self.mc_classout(Features,training=True)
      Classes = tf.cast(Classes,y_mc.dtype)

      mc_loss = tf.keras.losses.categorical_crossentropy(y_mc,Classes)
      # mc_loss = tf.reduce_mean(mc_loss)
      mc_acc = tf.keras.metrics.categorical_accuracy(y_mc,Classes)
      # mc_acc = tf.reduce_mean(mc_acc)

      self.mc_loss_tracker.update_state(mc_loss)
      self.mc_acc_tracker.update_state(mc_acc)

    mc_grad = mc_tape.gradient(mc_loss,self.feature_extractor.trainable_variables+self.mc_classout.trainable_variables)
    self.MC_opt.apply_gradients(zip(mc_grad,self.feature_extractor.trainable_variables+self.mc_classout.trainable_variables))

    with tf.GradientTape() as ml_tape:
      Features = self.feature_extractor(x,training=True)
      Labels = self.ml_classout(Features,training=True)
      Labels = tf.cast(Labels,y_ml.dtype)
      ml_loss = tf.keras.losses.binary_crossentropy(y_ml,Labels)
      # ml_loss = tf.reduce_mean(ml_loss)
      ml_acc = tf.keras.metrics.binary_accuracy(y_ml,Labels)
      # ml_acc = tf.reduce_mean(ml_acc)

      self.ml_loss_tracker.update_state(ml_loss)
      self.ml_acc_tracker.update_state(ml_acc)
    
    ml_grad = ml_tape.gradient(ml_loss,self.feature_extractor.trainable_variables+self.ml_classout.trainable_variables)
    self.ML_opt.apply_gradients(zip(ml_grad,self.feature_extractor.trainable_variables+self.ml_classout.trainable_variables))

    # total_loss = mc_loss + ml_loss
    self.total_loss_tracker.update_state(mc_loss+ml_loss)

    return {"Total loss":self.total_loss_tracker.result(), 
            "Multiclass loss":self.mc_loss_tracker.result(), "Multiclass acc":self.mc_acc_tracker.result(),
            "Multilabel loss":self.ml_loss_tracker.result(), "Multilabel acc":self.ml_acc_tracker.result()}

  def call(self, inputs):
    Features = self.feature_extractor(inputs)
    Classes = self.mc_classout(Features)
    Labels = self.ml_classout(Features)

    return Classes, Labels

  # def metrics(self):
  #     # We list our `Metric` objects here so that `reset_states()` can be
  #     # called automatically at the start of each epoch
  #     # or at the start of `evaluate()`.
  #     # If you don't implement this property, you have to call
  #     # `reset_states()` yourself at the time of your choosing.
  #     return [self.total_loss_tracker,self.mc_loss_tracker,self.mc_acc_tracker,self.ml_loss_tracker,self.ml_acc_tracker]